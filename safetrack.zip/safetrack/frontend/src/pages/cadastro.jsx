import Login from './login';

export default function Cadastro() {
    return <Login isCadastro={true} />;
}
