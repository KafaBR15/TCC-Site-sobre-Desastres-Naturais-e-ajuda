# DATA QUERY LANGUAGE

SELECT * FROM tb_usuario;

SELECT * FROM tb_livro;