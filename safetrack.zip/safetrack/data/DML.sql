# DATA MANIPULATION LANGUAGE

USE LivrariaDB;

# Senha: 1234
INSERT INTO tb_usuario VALUES (0, 'admin', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'); 

INSERT INTO tb_livro VALUES (0, 'Fahrenheit 451', 'Ray Bradbury', 'https://m.media-amazon.com/images/I/51tAD6LyZ-L._AC_UF1000,1000_QL80_.jpg');